from __future__ import unicode_literals

from datetime import datetime
from django.db import models

# Create your models here.

class Entidad(models.Model):
	nombre = models.CharField(max_length=200);
	fechaInicio = models.DateField();
	genero = models.CharField(max_length=100);

	def __str__(self):
		return "Nombre de la entidad musical: %s" % (self.nombre)

class Genero(models.Model):
	nombre = models.CharField(max_length=100);

class Publicacion(models.Model):
	titulo = models.CharField(max_length = 100);
	cuerpo = models.CharField(max_length=200);
	fechaInicio = models.DateTimeField(auto_now_add=True, blank=True);
	entidadID = models.ForeignKey(Entidad, on_delete=models.CASCADE);

class Album(models.Model):
	nombre = models.CharField(max_length=200);
	entidadID = models.ForeignKey(Entidad, on_delete=models.CASCADE);

""" EJEMPLO de llaves foraneas
class Reporter(models.Model):
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=30)
    email = models.EmailField()

    def __str__(self):              # __unicode__ on Python 2
        return "%s %s" % (self.first_name, self.last_name)

class Article(models.Model):
    headline = models.CharField(max_length=100)
    pub_date = models.DateField()
    reporter = models.ForeignKey(Reporter, on_delete=models.CASCADE)
"""