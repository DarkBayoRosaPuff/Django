from django.shortcuts import render

from django.http import HttpResponse
from .models import TestTable
from django.template import loader

# Create your views here.
def consultar(request):
	contenido = TestTable.objects.all()
	plantilla = loader.get_template('index.html')
	contexto = {
		'contenido': contenido,
	}
	return HttpResponse(plantilla.render(contexto,request))

def agregar(request):
	nuevo = TestTable(valor = request.POST['valor'])
	nuevo.save()
	return consultar(request)