from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseRedirect

from django.http import HttpResponse
from django.template import loader
from django.shortcuts import render

from Modelos.models import Entidad

# Create your views here.

def nuevo_usuario(request):
	#Accion de registrar un usuario
	if request.method=='POST':
		formulario = UserCreationForm(request.POST)
		if formulario.is_valid():
			formulario.save()
			return HttpResponseRedirect('/') #Si fue valido, guardamos y nos quedamos ahi
	else:
		#Lo necesario para la pagina principal
		formulario = UserCreationForm()
		catalogo = Entidad.objects.all()
		plantilla = loader.get_template('nuevoUsuario.html')
		contexto = {
		'formulario': formulario,
		'catalogo': catalogo,
		}
	return HttpResponse(plantilla.render(contexto,request))
	#return render(request, 'nuevoUsuario.html', {'formulario':formulario, 'catalogo':catalogo})